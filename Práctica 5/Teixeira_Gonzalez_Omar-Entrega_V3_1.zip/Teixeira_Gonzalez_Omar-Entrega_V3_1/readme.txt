Omar Teixeira González:

Ejercicios 1, 2 y 3.

:-)