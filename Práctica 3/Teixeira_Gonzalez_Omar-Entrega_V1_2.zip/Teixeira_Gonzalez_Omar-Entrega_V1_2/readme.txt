Omar Teixeira González:

Ejercicios 4, 5, 6, 7.

Ejercicio 4:
Queda en ejecución el SystemIdleProcess, que ejecuta un bucle infinito que no hace nada, 
de esta forma el procesador no está parado, ya que, el numero de programas es mayor al soportado.

Ejercicio 6:
Debido a que este supera al máximo reservado en memoria principal

:-)