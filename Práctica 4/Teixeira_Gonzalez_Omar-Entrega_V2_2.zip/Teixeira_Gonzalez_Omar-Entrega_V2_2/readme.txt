Omar Teixeira González:

Ejercicios 5, 6, 7 y 8

:-)