Omar Teixeira González:

Ejercicios 8, 9 y 10.

Al no haber sido posible realizar el ejercicio 11 la salida no incluirá lo que debe.

:-)