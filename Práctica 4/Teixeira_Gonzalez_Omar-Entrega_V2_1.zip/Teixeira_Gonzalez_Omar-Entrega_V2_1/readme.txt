Omar Teixeira González:

Ejercicios 1, 2, 3 y 4.

:-)