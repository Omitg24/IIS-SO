Omar Teixeira González:

Ejercicios 0, 1, 2 y 3.

Ejercicio 3:
No se ejecuta 2 veces debido a la instrucción HALT, para ello se utiliza la instrucción TRAP 3.

:-)